module.exports = {
    mongoURI:'mongodb+srv://jaewon:1234@cluster0.m7e0r.mongodb.net/test?retryWrites=true&w=majority'
}